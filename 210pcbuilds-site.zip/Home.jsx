
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const builds = [
  {
    name: "Blackout Beast",
    case: "Lian Li A4 H2O (Black)",
    specs: [
      "CPU: AMD Ryzen 7 9800X3D",
      "GPU: NVIDIA RTX 5080 FE 16GB",
      "RAM: 32GB Xflare DDR5 CL36",
      "Motherboard: Gigabyte AORUS Ultra ITX",
      "Storage: 2TB Samsung 980 NVMe",
      "Cooler: Deepcool LT520 240mm AIO",
      "PSU: Corsair SF750 SFX Modular"
    ],
    img: "/blackout-beast-1.jpeg"
  },
  {
    name: "RGB Specter",
    case: "Lian Li A4 H2O (Silver)",
    specs: [
      "CPU: AMD Ryzen 7 9800X3D",
      "GPU: NVIDIA RTX 5080 FE 16GB",
      "RAM: 32GB Corsair Vengeance DDR5 RGB",
      "Motherboard: ASUS ROG STRIX B650E-I",
      "Storage: 4TB WD_BLACK SN850 NVMe",
      "Cooler: Cooler Master AIO",
      "PSU: Corsair SF750 SFX Modular"
    ],
    img: "/rgb-specter-1.jpeg"
  }
];

export default function Home() {
  return (
    <div className="bg-black min-h-screen text-purple-300 font-mono">
      <div className="text-center py-10">
        <h1 className="text-4xl md:text-6xl font-bold neon-text">210PCBuilds</h1>
        <p className="text-lg mt-4">Custom-built SFF gaming rigs. Locally crafted. Globally impressive.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6 px-4 md:px-16">
        {builds.map((build, idx) => (
          <Card key={idx} className="bg-gray-900 border-purple-500 shadow-lg hover:scale-105 transition-transform duration-300">
            <img src={build.img} alt={build.name} className="w-full h-64 object-cover rounded-t-lg" />
            <CardContent className="p-4">
              <h2 className="text-2xl font-semibold mb-2 text-purple-400">{build.name}</h2>
              <p className="text-sm italic text-gray-400 mb-2">{build.case}</p>
              <ul className="list-disc list-inside text-sm text-gray-300">
                {build.specs.map((line, i) => <li key={i}>{line}</li>)}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center mt-16 pb-10">
        <h2 className="text-3xl font-bold text-purple-300 mb-4">Request a Custom Build</h2>
        <form
          action="https://formspree.io/f/mwkgyvka"
          method="POST"
          className="max-w-xl mx-auto bg-gray-900 p-6 rounded-lg border border-purple-700"
        >
          <div className="mb-4">
            <label className="block text-left mb-1 text-sm">Name</label>
            <input type="text" name="name" required className="w-full p-2 bg-black border border-purple-500 rounded" />
          </div>
          <div className="mb-4">
            <label className="block text-left mb-1 text-sm">Email</label>
            <input type="email" name="email" required className="w-full p-2 bg-black border border-purple-500 rounded" />
          </div>
          <div className="mb-4">
            <label className="block text-left mb-1 text-sm">Budget</label>
            <input type="text" name="budget" className="w-full p-2 bg-black border border-purple-500 rounded" />
          </div>
          <div className="mb-4">
            <label className="block text-left mb-1 text-sm">Build Purpose</label>
            <input type="text" name="purpose" className="w-full p-2 bg-black border border-purple-500 rounded" />
          </div>
          <div className="mb-4">
            <label className="block text-left mb-1 text-sm">Message</label>
            <textarea name="message" rows="4" className="w-full p-2 bg-black border border-purple-500 rounded"></textarea>
          </div>
          <button type="submit" className="bg-purple-600 hover:bg-purple-500 text-white px-6 py-2 rounded-full">
            Send Request
          </button>
        </form>
      </div>
    </div>
  );
}
